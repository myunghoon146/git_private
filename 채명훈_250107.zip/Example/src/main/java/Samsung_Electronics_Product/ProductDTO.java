package Samsung_Electronics_Product;

public class ProductDTO {


    private String productName;
    private int productPrice;
    private short numberofsellingproduct;


    public ProductDTO(String productName, int productPrice, short numberofsellingproduct) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.numberofsellingproduct = numberofsellingproduct;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public short getNumberofsellingproduct() {
        return numberofsellingproduct;
    }

    @Override
    public String toString() {
        return "ProductDTO{" +
                "productName='" + productName + '\'' +
                ", productPrice=" + productPrice +
                ", numberofsellingproduct=" + numberofsellingproduct +
                '}';
    }

    public void setNumberofsellingproduct(short numberofsellingproduct) {
        this.numberofsellingproduct = numberofsellingproduct;











    }



        public void getProductName{


        System.out.println("Product Name = " + productName);







    }

        public void getProductPrice{


        System.out.println("Product Price = " + productPrice);












    }


    public void getnumberofsellingproduct () {


        System.out.println("Number of selling product = " + numberofsellingproduct);



    }



}
