package Samsung_Electronics_Product;

import java.util.ArrayList;
import java.util.Collection;

public class Application {


    public static void main(String[] args) {




        Collection listofproduct = new ArrayList();

        listofproduct.add("Galaxy S6",350000, 789);
        listofproduct.add("Galaxy A5", 580000, 357);
        listofproduct.add("Galaxy B7", 675000, 500);
        listofproduct.add("Galaxy C9", 600000, 350);
        listofproduct.add("Galaxy S10", 800000, 500);


        System.out.println("listofproduct=" + listofproduct);
        System.out.println(1."제품을 추가합니다.");
        System.out.println(2."제품 가격을 올립니다.");
        System.out.println(3."제품 판매 개수를 올립니다." );

        for (int i = 0; i < listofproduct.size(); i++) {


            System.out.println(4. "제품리스트안에서 조회가능합니다.");



        }

        if (boolean listofproduct = false) {


            System.out.println(9. "프로그램을 종료합니다.");




        }





















    }



}
