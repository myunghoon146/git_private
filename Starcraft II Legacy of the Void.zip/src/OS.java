import java.lang.reflect.Method;

public class OS {

    public static void main(String[] args) {


        Method A = "Windows 7";
        System.out.println("Method A Signalling");

        Method B = "Windows 8";
        System.out.println("Method B Signalling");

        Method C = "Windows 10";
        System.out.println("Method C Signalling");

        Method D= "Windows 11";
        System.out.println("Method D Signalling");

        Method E = "Windows 12";
        System.out.println("Method E Signalling");










    }


}
