package Game_Interface;

public interface Interface {

    "Pixel for PC Monitor 350x273"




}
