package Enemy;

public class Zerg {




    while (Zerg) {

        System.out.println("Zerg is enemy.");
        double Zerg = 582.73;
    }







}
