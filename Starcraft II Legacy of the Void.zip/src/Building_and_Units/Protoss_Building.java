package Building_and_Units;

public class Protoss_Building {


    public static void main(String[] args) {

        String CommandCenter;
        long CommandCenter = 5302;

        System.out.println(CommandCenter);
        System.out.println("Produce SCV");

        String Barrack;
        short Barrack = 350758;
        System.out.println(Barrack);
        System.out.println("Produce Laser Swordman, Marine, Medic and Ghost");

        String EngineeringBay;
        double EngineeringBay = 982.5;
        System.out.println(EngineeringBay);
        System.out.println("Upgrade Barrack Units");

        String Bunker;
        int Bunker = 827.35;
        System.out.println(Bunker);


        String Academy;
        short Academy = 785.2;
        System.out.println(Academy);
        System.out.println("Upgrade Unit's Skills");

        String Factory;
        float Factory = 572.35;
        System.out.println(Factory);
        System.out.println("Produce Ecrite Tank, Goliath and Artoria Vulture");

        String Armory;
        int Armory = 827.5;
        System.out.println(Armory);
        System.out.println("Upgrade Machine Units");

        String Starport;
        double Starport = 572.3;
        System.out.println(Starport);
        System.out.println("Produce Wraith, Dropship and Battlecruiser");

        String ScienceFacility;
        float ScienceFacility = 375.27538;
        System.out.println(ScienceFacility);








    }



}
